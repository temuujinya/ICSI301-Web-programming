<?php
    require_once('./include/initialize.php');
    log_out();
    redirect_to(url_for('/login.php'));
?>