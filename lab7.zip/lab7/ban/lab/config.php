<?php
$site_url="http://localhost/weblab7";
?>
