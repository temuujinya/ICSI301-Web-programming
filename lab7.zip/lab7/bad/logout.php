<?php
    require_once('./logic/initialize.php');
    log_out();
    redirect_to(url_for('/login.php'));
?>