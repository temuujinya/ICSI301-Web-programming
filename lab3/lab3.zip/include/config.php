<?php
$site_url="http://localhost/weblab3";
?>