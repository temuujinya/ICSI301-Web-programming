<?php
if(!isset($studentsFilePath)){
    $studentsFilePath="data/students.json";
}
if(!isset($coursesFilePath)){
    $coursesFilePath="data/courses.json";
}

?>