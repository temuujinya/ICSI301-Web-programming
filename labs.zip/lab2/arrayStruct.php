<?php 
$courses = [
  "ICSI201"=>[
    "name"=>"Объект хандалтат програмчлал",
    "ID"=>"ICSI201",
    "credit"=>3
  ],
  "ICSI202"=>[
    "name"=>"Өгөгдлийн бүтэц",
    "ID"=>"ICSI202",
    "credit"=>3
  ],
  "ICSI203"=>[
    "name"=>"Магадлал статистик",
    "ID"=>"ICSI203",
    "credit"=>3
  ],
  "ICSI301"=>[
    "name"=>"Веб програмчлал",
    "ID"=>"ICSI301",
    "credit"=>3
  ],
  "ICSI432"=>[
    "name"=>"Компьютер график",
    "ID"=>"ICSI432",
    "credit"=>3
  ],
  ];


$students = array(
  "16b1seas3369"=>array(
    "fname"=>"Steve",
    "lname"=>"Jobs",
    "sisiID"=>"16b1seas3369",
    "program"=>"SE",
    "courses"=>[]
  ),
  "16b1seas3370"=>array(
    "fname"=>"Bill",
    "lname"=>"Gates",
    "sisiID"=>"16b1seas3370",
    "program"=>"SE",
    "courses"=>[]
  ),
  "16b1seas3371"=>array(
    "fname"=>"Zuckerberg",
    "lname"=>"Mark",
    "sisiID"=>"16b1seas3371",
    "program"=>"SE",
    "courses"=>[]
  ),
  "16b1seas3372"=>array(
    "fname"=>"Амархүү",
    "lname"=>"Ган-Эрдэнэ",
    "sisiID"=>"16b1seas3372",
    "program"=>"SE",
    "courses"=>[]
  ),
  "16b1seas3373"=>array(
    "fname"=>"Явуухулан",
    "lname"=>"Эрдэнэ",
    "sisiID"=>"16b1seas3373",
    "program"=>"SE",
    "courses"=>[]
  ),
  "16b1seas3374"=>array(
    "fname"=>"Нисдэг луу",
    "lname"=>"Артан-Эрдэнэ",
    "sisiID"=>"16b1seas3374",
    "program"=>"SE",
    "courses"=>[]
  ),
  "16b1seas3375"=>array(
    "fname"=>"Абуу",
    "lname"=>"Ястай",
    "sisiID"=>"16b1seas3375",
    "program"=>"SE",
    "courses"=>[]
  ),
);

?>